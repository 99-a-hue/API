# Api_Task
 Api's Tasking
1. To add the sales data
   url: localhost:3000/id/name/amount/date - (date must be in a format like (DD-MM-YYYY))
2. To get data for weekly, daily, and monthly
	url : localhost:3000/daily - which gives on the date of hourly amount
	url : localhost:3000/weekly - which gives on the week of the data
	url : localhost:3000/monthly - which gives monthly data